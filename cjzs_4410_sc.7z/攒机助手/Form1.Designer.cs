﻿namespace 攒机助手
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Label13 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.CheckBoxamd = new System.Windows.Forms.CheckBox();
            this.Button1 = new System.Windows.Forms.Button();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.hezhuangcpu = new System.Windows.Forms.CheckBox();
            this.checknvgpu = new System.Windows.Forms.CheckBox();
            this.checkamdgpu = new System.Windows.Forms.CheckBox();
            this.checkBoxcpu = new System.Windows.Forms.CheckBox();
            this.checkBoxe3 = new System.Windows.Forms.CheckBox();
            this.checkBoxgpu = new System.Windows.Forms.CheckBox();
            this.checkBoxk = new System.Windows.Forms.CheckBox();
            this.checkBoxdouble = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.Label1 = new System.Windows.Forms.Label();
            this.textBoxkb1 = new System.Windows.Forms.TextBox();
            this.textBoxkb = new System.Windows.Forms.TextBox();
            this.checkBoxkb = new System.Windows.Forms.CheckBox();
            this.checkBoxcdrom = new System.Windows.Forms.CheckBox();
            this.textBoxcdrom1 = new System.Windows.Forms.TextBox();
            this.textBoxcdrom = new System.Windows.Forms.TextBox();
            this.checkBoxssd = new System.Windows.Forms.CheckBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.TextBoxpower = new System.Windows.Forms.TextBox();
            this.TextBoxpower1 = new System.Windows.Forms.TextBox();
            this.TextBoxcpu = new System.Windows.Forms.TextBox();
            this.TextBoxfan = new System.Windows.Forms.TextBox();
            this.TextBoxfan1 = new System.Windows.Forms.TextBox();
            this.TextBoxcpu1 = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.TextBoxbox1 = new System.Windows.Forms.TextBox();
            this.TextBoxbox = new System.Windows.Forms.TextBox();
            this.TextBoxmb1 = new System.Windows.Forms.TextBox();
            this.TextBoxlcd1 = new System.Windows.Forms.TextBox();
            this.TextBoxlcd = new System.Windows.Forms.TextBox();
            this.TextBoxram1 = new System.Windows.Forms.TextBox();
            this.TextBoxgpu1 = new System.Windows.Forms.TextBox();
            this.TextBoxgpu = new System.Windows.Forms.TextBox();
            this.TextBoxhdd1 = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.TextBoxhdd = new System.Windows.Forms.TextBox();
            this.checkBoxfan = new System.Windows.Forms.CheckBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.checkBoxbox = new System.Windows.Forms.CheckBox();
            this.label25 = new System.Windows.Forms.Label();
            this.TextBoxram = new System.Windows.Forms.TextBox();
            this.CheckBoxlcd = new System.Windows.Forms.CheckBox();
            this.checkBoxhdd = new System.Windows.Forms.CheckBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.TextBoxmb = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.textBoxssd = new System.Windows.Forms.TextBox();
            this.textBoxssd1 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.labelall = new System.Windows.Forms.Label();
            this.labelcopy = new System.Windows.Forms.Label();
            this.labelprint = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.labeldate = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.buttonexpand = new System.Windows.Forms.Button();
            this.ComboBoxpower = new System.Windows.Forms.ComboBox();
            this.ComboBoxfan = new System.Windows.Forms.ComboBox();
            this.ComboBoxbox = new System.Windows.Forms.ComboBox();
            this.ComboBoxlcd = new System.Windows.Forms.ComboBox();
            this.ComboBoxgpu = new System.Windows.Forms.ComboBox();
            this.ComboBoxhdd = new System.Windows.Forms.ComboBox();
            this.ComboBoxram = new System.Windows.Forms.ComboBox();
            this.ComboBoxmb = new System.Windows.Forms.ComboBox();
            this.ComboBoxcpu = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.kbsrbox = new System.Windows.Forms.TextBox();
            this.cdromsrbox = new System.Windows.Forms.TextBox();
            this.powersrBox = new System.Windows.Forms.TextBox();
            this.fansrBox = new System.Windows.Forms.TextBox();
            this.boxsrbox = new System.Windows.Forms.TextBox();
            this.lcdsrBox = new System.Windows.Forms.TextBox();
            this.ssdsrBox = new System.Windows.Forms.TextBox();
            this.comboBoxssd = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.gpusrbox = new System.Windows.Forms.TextBox();
            this.comboBoxkb = new System.Windows.Forms.ComboBox();
            this.hddsrbox = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.ramsrbox = new System.Windows.Forms.TextBox();
            this.ComboBoxcdrom = new System.Windows.Forms.ComboBox();
            this.mbsrbox = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.cpusrbox = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.启动时自动检查更新ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.检查更新ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.反馈建议ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pzToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.关于ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.价格更新ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.labelvisit = new System.Windows.Forms.Label();
            this.labelad = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.Location = new System.Drawing.Point(253, 0);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(34, 25);
            this.Label13.TabIndex = 50;
            this.Label13.Text = "元";
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Location = new System.Drawing.Point(-134, 125);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(91, 13);
            this.Label12.TabIndex = 49;
            this.Label12.Text = "请输入预算金额";
            // 
            // CheckBoxamd
            // 
            this.CheckBoxamd.AutoSize = true;
            this.CheckBoxamd.Location = new System.Drawing.Point(3, 3);
            this.CheckBoxamd.Name = "CheckBoxamd";
            this.CheckBoxamd.Size = new System.Drawing.Size(86, 17);
            this.CheckBoxamd.TabIndex = 48;
            this.CheckBoxamd.Text = "AMD处理器";
            this.CheckBoxamd.UseVisualStyleBackColor = true;
            this.CheckBoxamd.CheckedChanged += new System.EventHandler(this.CheckBoxamd_CheckedChanged);
            // 
            // Button1
            // 
            this.Button1.Location = new System.Drawing.Point(293, 3);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(109, 31);
            this.Button1.TabIndex = 1;
            this.Button1.Text = "智能攒机";
            this.Button1.UseVisualStyleBackColor = true;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // TextBox1
            // 
            this.TextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox1.Location = new System.Drawing.Point(113, 3);
            this.TextBox1.MaxLength = 5;
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(134, 31);
            this.TextBox1.TabIndex = 0;
            this.TextBox1.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            this.TextBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox1_KeyPress);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel10);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(343, 94);
            this.groupBox1.TabIndex = 51;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "配置要求";
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 3;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33332F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel10.Controls.Add(this.CheckBoxamd, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.hezhuangcpu, 0, 2);
            this.tableLayoutPanel10.Controls.Add(this.checknvgpu, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.checkamdgpu, 2, 0);
            this.tableLayoutPanel10.Controls.Add(this.checkBoxcpu, 1, 1);
            this.tableLayoutPanel10.Controls.Add(this.checkBoxe3, 2, 2);
            this.tableLayoutPanel10.Controls.Add(this.checkBoxgpu, 2, 1);
            this.tableLayoutPanel10.Controls.Add(this.checkBoxk, 1, 2);
            this.tableLayoutPanel10.Controls.Add(this.checkBoxdouble, 0, 1);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 3;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(337, 75);
            this.tableLayoutPanel10.TabIndex = 82;
            // 
            // hezhuangcpu
            // 
            this.hezhuangcpu.AutoSize = true;
            this.hezhuangcpu.Location = new System.Drawing.Point(3, 53);
            this.hezhuangcpu.Name = "hezhuangcpu";
            this.hezhuangcpu.Size = new System.Drawing.Size(72, 17);
            this.hezhuangcpu.TabIndex = 84;
            this.hezhuangcpu.Text = "盒装CPU";
            this.hezhuangcpu.UseVisualStyleBackColor = true;
            this.hezhuangcpu.CheckedChanged += new System.EventHandler(this.hezhuangcpu_CheckedChanged);
            // 
            // checknvgpu
            // 
            this.checknvgpu.AutoSize = true;
            this.checknvgpu.Location = new System.Drawing.Point(115, 3);
            this.checknvgpu.Name = "checknvgpu";
            this.checknvgpu.Size = new System.Drawing.Size(86, 17);
            this.checknvgpu.TabIndex = 85;
            this.checknvgpu.Text = "NVIDIA显卡";
            this.checknvgpu.UseVisualStyleBackColor = true;
            this.checknvgpu.CheckedChanged += new System.EventHandler(this.checknvgpu_CheckedChanged);
            // 
            // checkamdgpu
            // 
            this.checkamdgpu.AutoSize = true;
            this.checkamdgpu.Location = new System.Drawing.Point(227, 3);
            this.checkamdgpu.Name = "checkamdgpu";
            this.checkamdgpu.Size = new System.Drawing.Size(74, 17);
            this.checkamdgpu.TabIndex = 86;
            this.checkamdgpu.Text = "AMD显卡";
            this.checkamdgpu.UseVisualStyleBackColor = true;
            this.checkamdgpu.CheckedChanged += new System.EventHandler(this.checkamdgpu_CheckedChanged);
            // 
            // checkBoxcpu
            // 
            this.checkBoxcpu.AutoSize = true;
            this.checkBoxcpu.Location = new System.Drawing.Point(115, 28);
            this.checkBoxcpu.Name = "checkBoxcpu";
            this.checkBoxcpu.Size = new System.Drawing.Size(84, 17);
            this.checkBoxcpu.TabIndex = 49;
            this.checkBoxcpu.Text = "较高档CPU";
            this.checkBoxcpu.UseVisualStyleBackColor = true;
            // 
            // checkBoxe3
            // 
            this.checkBoxe3.AutoSize = true;
            this.checkBoxe3.Location = new System.Drawing.Point(227, 53);
            this.checkBoxe3.Name = "checkBoxe3";
            this.checkBoxe3.Size = new System.Drawing.Size(64, 17);
            this.checkBoxe3.TabIndex = 83;
            this.checkBoxe3.Text = "E3 CPU";
            this.checkBoxe3.UseVisualStyleBackColor = true;
            this.checkBoxe3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBoxgpu
            // 
            this.checkBoxgpu.AutoSize = true;
            this.checkBoxgpu.Location = new System.Drawing.Point(227, 28);
            this.checkBoxgpu.Name = "checkBoxgpu";
            this.checkBoxgpu.Size = new System.Drawing.Size(86, 17);
            this.checkBoxgpu.TabIndex = 81;
            this.checkBoxgpu.Text = "较高档显卡";
            this.checkBoxgpu.UseVisualStyleBackColor = true;
            this.checkBoxgpu.CheckedChanged += new System.EventHandler(this.checkBoxgpu_CheckedChanged);
            // 
            // checkBoxk
            // 
            this.checkBoxk.AutoSize = true;
            this.checkBoxk.Location = new System.Drawing.Point(115, 53);
            this.checkBoxk.Name = "checkBoxk";
            this.checkBoxk.Size = new System.Drawing.Size(96, 17);
            this.checkBoxk.TabIndex = 71;
            this.checkBoxk.Text = "不锁倍频CPU";
            this.checkBoxk.UseVisualStyleBackColor = true;
            this.checkBoxk.CheckedChanged += new System.EventHandler(this.checkBoxk_CheckedChanged);
            // 
            // checkBoxdouble
            // 
            this.checkBoxdouble.AutoSize = true;
            this.checkBoxdouble.Location = new System.Drawing.Point(3, 28);
            this.checkBoxdouble.Name = "checkBoxdouble";
            this.checkBoxdouble.Size = new System.Drawing.Size(86, 17);
            this.checkBoxdouble.TabIndex = 82;
            this.checkBoxdouble.Text = "双通道内存";
            this.checkBoxdouble.UseVisualStyleBackColor = true;
            this.checkBoxdouble.CheckedChanged += new System.EventHandler(this.checkBoxdouble_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tableLayoutPanel8);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.Label11);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 63);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(430, 400);
            this.groupBox2.TabIndex = 58;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "参考配置单";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel7, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel9, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.label31, 0, 3);
            this.tableLayoutPanel8.Controls.Add(this.labeldate, 0, 2);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 4;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(424, 381);
            this.tableLayoutPanel8.TabIndex = 101;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 4;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel7.Controls.Add(this.Label1, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.textBoxkb1, 3, 11);
            this.tableLayoutPanel7.Controls.Add(this.textBoxkb, 2, 11);
            this.tableLayoutPanel7.Controls.Add(this.checkBoxkb, 0, 11);
            this.tableLayoutPanel7.Controls.Add(this.checkBoxcdrom, 0, 10);
            this.tableLayoutPanel7.Controls.Add(this.textBoxcdrom1, 3, 10);
            this.tableLayoutPanel7.Controls.Add(this.textBoxcdrom, 2, 10);
            this.tableLayoutPanel7.Controls.Add(this.checkBoxssd, 0, 4);
            this.tableLayoutPanel7.Controls.Add(this.Label2, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.label29, 1, 4);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxpower, 2, 9);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxpower1, 3, 9);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxcpu, 2, 0);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxfan, 2, 8);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxfan1, 3, 8);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxcpu1, 3, 0);
            this.tableLayoutPanel7.Controls.Add(this.Label3, 1, 2);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxbox1, 3, 7);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxbox, 2, 7);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxmb1, 3, 1);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxlcd1, 3, 6);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxlcd, 2, 6);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxram1, 3, 2);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxgpu1, 3, 5);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxgpu, 2, 5);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxhdd1, 3, 3);
            this.tableLayoutPanel7.Controls.Add(this.Label4, 1, 3);
            this.tableLayoutPanel7.Controls.Add(this.Label5, 1, 5);
            this.tableLayoutPanel7.Controls.Add(this.Label6, 1, 6);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxhdd, 2, 3);
            this.tableLayoutPanel7.Controls.Add(this.checkBoxfan, 0, 8);
            this.tableLayoutPanel7.Controls.Add(this.Label7, 1, 7);
            this.tableLayoutPanel7.Controls.Add(this.checkBoxbox, 0, 7);
            this.tableLayoutPanel7.Controls.Add(this.label25, 1, 11);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxram, 2, 2);
            this.tableLayoutPanel7.Controls.Add(this.CheckBoxlcd, 0, 6);
            this.tableLayoutPanel7.Controls.Add(this.checkBoxhdd, 0, 3);
            this.tableLayoutPanel7.Controls.Add(this.Label8, 1, 8);
            this.tableLayoutPanel7.Controls.Add(this.label24, 1, 10);
            this.tableLayoutPanel7.Controls.Add(this.TextBoxmb, 2, 1);
            this.tableLayoutPanel7.Controls.Add(this.Label10, 1, 9);
            this.tableLayoutPanel7.Controls.Add(this.textBoxssd, 2, 4);
            this.tableLayoutPanel7.Controls.Add(this.textBoxssd1, 3, 4);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 12;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(418, 305);
            this.tableLayoutPanel7.TabIndex = 100;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(23, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(44, 15);
            this.Label1.TabIndex = 70;
            this.Label1.Text = "CPU：";
            // 
            // textBoxkb1
            // 
            this.textBoxkb1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBoxkb1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBoxkb1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxkb1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxkb1.ForeColor = System.Drawing.Color.Blue;
            this.textBoxkb1.Location = new System.Drawing.Point(355, 278);
            this.textBoxkb1.Name = "textBoxkb1";
            this.textBoxkb1.ReadOnly = true;
            this.textBoxkb1.Size = new System.Drawing.Size(60, 23);
            this.textBoxkb1.TabIndex = 96;
            this.toolTip1.SetToolTip(this.textBoxkb1, "点击查看详情");
            this.textBoxkb1.Click += new System.EventHandler(this.textBoxkb1_Click);
            // 
            // textBoxkb
            // 
            this.textBoxkb.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBoxkb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxkb.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxkb.Location = new System.Drawing.Point(93, 278);
            this.textBoxkb.Name = "textBoxkb";
            this.textBoxkb.ReadOnly = true;
            this.textBoxkb.Size = new System.Drawing.Size(256, 23);
            this.textBoxkb.TabIndex = 97;
            // 
            // checkBoxkb
            // 
            this.checkBoxkb.AutoSize = true;
            this.checkBoxkb.Location = new System.Drawing.Point(3, 278);
            this.checkBoxkb.Name = "checkBoxkb";
            this.checkBoxkb.Size = new System.Drawing.Size(14, 14);
            this.checkBoxkb.TabIndex = 91;
            this.checkBoxkb.UseVisualStyleBackColor = true;
            // 
            // checkBoxcdrom
            // 
            this.checkBoxcdrom.AutoSize = true;
            this.checkBoxcdrom.Location = new System.Drawing.Point(3, 253);
            this.checkBoxcdrom.Name = "checkBoxcdrom";
            this.checkBoxcdrom.Size = new System.Drawing.Size(14, 14);
            this.checkBoxcdrom.TabIndex = 90;
            this.checkBoxcdrom.UseVisualStyleBackColor = true;
            // 
            // textBoxcdrom1
            // 
            this.textBoxcdrom1.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxcdrom1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBoxcdrom1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxcdrom1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxcdrom1.ForeColor = System.Drawing.Color.Blue;
            this.textBoxcdrom1.Location = new System.Drawing.Point(355, 253);
            this.textBoxcdrom1.Name = "textBoxcdrom1";
            this.textBoxcdrom1.ReadOnly = true;
            this.textBoxcdrom1.Size = new System.Drawing.Size(60, 23);
            this.textBoxcdrom1.TabIndex = 94;
            this.toolTip1.SetToolTip(this.textBoxcdrom1, "点击查看详情");
            this.textBoxcdrom1.Click += new System.EventHandler(this.textBoxcdrom1_Click);
            // 
            // textBoxcdrom
            // 
            this.textBoxcdrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxcdrom.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxcdrom.Location = new System.Drawing.Point(93, 253);
            this.textBoxcdrom.Name = "textBoxcdrom";
            this.textBoxcdrom.ReadOnly = true;
            this.textBoxcdrom.Size = new System.Drawing.Size(256, 23);
            this.textBoxcdrom.TabIndex = 95;
            // 
            // checkBoxssd
            // 
            this.checkBoxssd.AutoSize = true;
            this.checkBoxssd.Location = new System.Drawing.Point(3, 103);
            this.checkBoxssd.Name = "checkBoxssd";
            this.checkBoxssd.Size = new System.Drawing.Size(14, 14);
            this.checkBoxssd.TabIndex = 99;
            this.checkBoxssd.UseVisualStyleBackColor = true;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(23, 25);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(43, 15);
            this.Label2.TabIndex = 71;
            this.Label2.Text = "主板：";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(23, 100);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(58, 15);
            this.label29.TabIndex = 98;
            this.label29.Text = "固态硬盘:";
            // 
            // TextBoxpower
            // 
            this.TextBoxpower.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TextBoxpower.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxpower.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxpower.Location = new System.Drawing.Point(93, 228);
            this.TextBoxpower.Name = "TextBoxpower";
            this.TextBoxpower.ReadOnly = true;
            this.TextBoxpower.Size = new System.Drawing.Size(256, 23);
            this.TextBoxpower.TabIndex = 56;
            // 
            // TextBoxpower1
            // 
            this.TextBoxpower1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TextBoxpower1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TextBoxpower1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxpower1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxpower1.ForeColor = System.Drawing.Color.Blue;
            this.TextBoxpower1.Location = new System.Drawing.Point(355, 228);
            this.TextBoxpower1.Name = "TextBoxpower1";
            this.TextBoxpower1.ReadOnly = true;
            this.TextBoxpower1.Size = new System.Drawing.Size(60, 23);
            this.TextBoxpower1.TabIndex = 30;
            this.toolTip1.SetToolTip(this.TextBoxpower1, "点击查看详情");
            this.TextBoxpower1.Click += new System.EventHandler(this.TextBoxpower1_Click);
            // 
            // TextBoxcpu
            // 
            this.TextBoxcpu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxcpu.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxcpu.Location = new System.Drawing.Point(93, 3);
            this.TextBoxcpu.Name = "TextBoxcpu";
            this.TextBoxcpu.ReadOnly = true;
            this.TextBoxcpu.Size = new System.Drawing.Size(256, 23);
            this.TextBoxcpu.TabIndex = 48;
            // 
            // TextBoxfan
            // 
            this.TextBoxfan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxfan.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxfan.Location = new System.Drawing.Point(93, 203);
            this.TextBoxfan.Name = "TextBoxfan";
            this.TextBoxfan.ReadOnly = true;
            this.TextBoxfan.Size = new System.Drawing.Size(256, 23);
            this.TextBoxfan.TabIndex = 55;
            // 
            // TextBoxfan1
            // 
            this.TextBoxfan1.BackColor = System.Drawing.SystemColors.Control;
            this.TextBoxfan1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TextBoxfan1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxfan1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxfan1.ForeColor = System.Drawing.Color.Blue;
            this.TextBoxfan1.Location = new System.Drawing.Point(355, 203);
            this.TextBoxfan1.Name = "TextBoxfan1";
            this.TextBoxfan1.ReadOnly = true;
            this.TextBoxfan1.Size = new System.Drawing.Size(60, 23);
            this.TextBoxfan1.TabIndex = 28;
            this.toolTip1.SetToolTip(this.TextBoxfan1, "点击查看详情");
            this.TextBoxfan1.Click += new System.EventHandler(this.TextBoxfan1_Click);
            // 
            // TextBoxcpu1
            // 
            this.TextBoxcpu1.BackColor = System.Drawing.SystemColors.Control;
            this.TextBoxcpu1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TextBoxcpu1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxcpu1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxcpu1.ForeColor = System.Drawing.Color.Blue;
            this.TextBoxcpu1.Location = new System.Drawing.Point(355, 3);
            this.TextBoxcpu1.Name = "TextBoxcpu1";
            this.TextBoxcpu1.ReadOnly = true;
            this.TextBoxcpu1.Size = new System.Drawing.Size(60, 23);
            this.TextBoxcpu1.TabIndex = 21;
            this.toolTip1.SetToolTip(this.TextBoxcpu1, "点击查看详情");
            this.TextBoxcpu1.Click += new System.EventHandler(this.TextBoxcpu1_Click);
            this.TextBoxcpu1.TextChanged += new System.EventHandler(this.TextBoxcpu1_TextChanged);
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(23, 50);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(43, 15);
            this.Label3.TabIndex = 72;
            this.Label3.Text = "内存：";
            // 
            // TextBoxbox1
            // 
            this.TextBoxbox1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TextBoxbox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TextBoxbox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxbox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxbox1.ForeColor = System.Drawing.Color.Blue;
            this.TextBoxbox1.Location = new System.Drawing.Point(355, 178);
            this.TextBoxbox1.Name = "TextBoxbox1";
            this.TextBoxbox1.ReadOnly = true;
            this.TextBoxbox1.Size = new System.Drawing.Size(60, 23);
            this.TextBoxbox1.TabIndex = 27;
            this.toolTip1.SetToolTip(this.TextBoxbox1, "点击查看详情");
            this.TextBoxbox1.Click += new System.EventHandler(this.TextBoxbox1_Click);
            // 
            // TextBoxbox
            // 
            this.TextBoxbox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TextBoxbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxbox.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxbox.Location = new System.Drawing.Point(93, 178);
            this.TextBoxbox.Name = "TextBoxbox";
            this.TextBoxbox.ReadOnly = true;
            this.TextBoxbox.Size = new System.Drawing.Size(256, 23);
            this.TextBoxbox.TabIndex = 54;
            // 
            // TextBoxmb1
            // 
            this.TextBoxmb1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TextBoxmb1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TextBoxmb1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxmb1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxmb1.ForeColor = System.Drawing.Color.Blue;
            this.TextBoxmb1.Location = new System.Drawing.Point(355, 28);
            this.TextBoxmb1.Name = "TextBoxmb1";
            this.TextBoxmb1.ReadOnly = true;
            this.TextBoxmb1.Size = new System.Drawing.Size(60, 23);
            this.TextBoxmb1.TabIndex = 22;
            this.toolTip1.SetToolTip(this.TextBoxmb1, "点击查看详情");
            this.TextBoxmb1.Click += new System.EventHandler(this.TextBoxmb1_Click);
            // 
            // TextBoxlcd1
            // 
            this.TextBoxlcd1.BackColor = System.Drawing.SystemColors.Control;
            this.TextBoxlcd1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TextBoxlcd1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxlcd1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxlcd1.ForeColor = System.Drawing.Color.Blue;
            this.TextBoxlcd1.Location = new System.Drawing.Point(355, 153);
            this.TextBoxlcd1.Name = "TextBoxlcd1";
            this.TextBoxlcd1.ReadOnly = true;
            this.TextBoxlcd1.Size = new System.Drawing.Size(60, 23);
            this.TextBoxlcd1.TabIndex = 26;
            this.toolTip1.SetToolTip(this.TextBoxlcd1, "点击查看详情");
            this.TextBoxlcd1.Click += new System.EventHandler(this.TextBoxlcd1_Click);
            // 
            // TextBoxlcd
            // 
            this.TextBoxlcd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxlcd.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxlcd.Location = new System.Drawing.Point(93, 153);
            this.TextBoxlcd.Name = "TextBoxlcd";
            this.TextBoxlcd.ReadOnly = true;
            this.TextBoxlcd.Size = new System.Drawing.Size(256, 23);
            this.TextBoxlcd.TabIndex = 53;
            // 
            // TextBoxram1
            // 
            this.TextBoxram1.BackColor = System.Drawing.SystemColors.Control;
            this.TextBoxram1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TextBoxram1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxram1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxram1.ForeColor = System.Drawing.Color.Blue;
            this.TextBoxram1.Location = new System.Drawing.Point(355, 53);
            this.TextBoxram1.Name = "TextBoxram1";
            this.TextBoxram1.ReadOnly = true;
            this.TextBoxram1.Size = new System.Drawing.Size(60, 23);
            this.TextBoxram1.TabIndex = 23;
            this.toolTip1.SetToolTip(this.TextBoxram1, "点击查看详情");
            this.TextBoxram1.Click += new System.EventHandler(this.TextBoxram1_Click);
            // 
            // TextBoxgpu1
            // 
            this.TextBoxgpu1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TextBoxgpu1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TextBoxgpu1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxgpu1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxgpu1.ForeColor = System.Drawing.Color.Blue;
            this.TextBoxgpu1.Location = new System.Drawing.Point(355, 128);
            this.TextBoxgpu1.Name = "TextBoxgpu1";
            this.TextBoxgpu1.ReadOnly = true;
            this.TextBoxgpu1.Size = new System.Drawing.Size(60, 23);
            this.TextBoxgpu1.TabIndex = 25;
            this.toolTip1.SetToolTip(this.TextBoxgpu1, "点击查看详情");
            this.TextBoxgpu1.Click += new System.EventHandler(this.TextBoxgpu1_Click);
            // 
            // TextBoxgpu
            // 
            this.TextBoxgpu.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TextBoxgpu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxgpu.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxgpu.Location = new System.Drawing.Point(93, 128);
            this.TextBoxgpu.Name = "TextBoxgpu";
            this.TextBoxgpu.ReadOnly = true;
            this.TextBoxgpu.Size = new System.Drawing.Size(256, 23);
            this.TextBoxgpu.TabIndex = 52;
            // 
            // TextBoxhdd1
            // 
            this.TextBoxhdd1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TextBoxhdd1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TextBoxhdd1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxhdd1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxhdd1.ForeColor = System.Drawing.Color.Blue;
            this.TextBoxhdd1.Location = new System.Drawing.Point(355, 78);
            this.TextBoxhdd1.Name = "TextBoxhdd1";
            this.TextBoxhdd1.ReadOnly = true;
            this.TextBoxhdd1.Size = new System.Drawing.Size(60, 23);
            this.TextBoxhdd1.TabIndex = 24;
            this.toolTip1.SetToolTip(this.TextBoxhdd1, "点击查看详情");
            this.TextBoxhdd1.Click += new System.EventHandler(this.TextBoxhdd1_Click);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(23, 75);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(43, 15);
            this.Label4.TabIndex = 73;
            this.Label4.Text = "硬盘：";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(23, 125);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(43, 15);
            this.Label5.TabIndex = 74;
            this.Label5.Text = "显卡：";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(23, 150);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(55, 15);
            this.Label6.TabIndex = 75;
            this.Label6.Text = "显示器：";
            // 
            // TextBoxhdd
            // 
            this.TextBoxhdd.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TextBoxhdd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxhdd.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxhdd.Location = new System.Drawing.Point(93, 78);
            this.TextBoxhdd.Name = "TextBoxhdd";
            this.TextBoxhdd.ReadOnly = true;
            this.TextBoxhdd.Size = new System.Drawing.Size(256, 23);
            this.TextBoxhdd.TabIndex = 51;
            // 
            // checkBoxfan
            // 
            this.checkBoxfan.AutoSize = true;
            this.checkBoxfan.Checked = true;
            this.checkBoxfan.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxfan.Location = new System.Drawing.Point(3, 203);
            this.checkBoxfan.Name = "checkBoxfan";
            this.checkBoxfan.Size = new System.Drawing.Size(14, 14);
            this.checkBoxfan.TabIndex = 75;
            this.checkBoxfan.UseVisualStyleBackColor = true;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.Location = new System.Drawing.Point(23, 175);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(43, 15);
            this.Label7.TabIndex = 76;
            this.Label7.Text = "机箱：";
            // 
            // checkBoxbox
            // 
            this.checkBoxbox.AutoSize = true;
            this.checkBoxbox.Checked = true;
            this.checkBoxbox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxbox.Location = new System.Drawing.Point(3, 178);
            this.checkBoxbox.Name = "checkBoxbox";
            this.checkBoxbox.Size = new System.Drawing.Size(14, 14);
            this.checkBoxbox.TabIndex = 81;
            this.checkBoxbox.UseVisualStyleBackColor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(23, 275);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(43, 15);
            this.label25.TabIndex = 93;
            this.label25.Text = "键鼠：";
            // 
            // TextBoxram
            // 
            this.TextBoxram.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxram.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxram.Location = new System.Drawing.Point(93, 53);
            this.TextBoxram.Name = "TextBoxram";
            this.TextBoxram.ReadOnly = true;
            this.TextBoxram.Size = new System.Drawing.Size(256, 23);
            this.TextBoxram.TabIndex = 50;
            // 
            // CheckBoxlcd
            // 
            this.CheckBoxlcd.AutoSize = true;
            this.CheckBoxlcd.Checked = true;
            this.CheckBoxlcd.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CheckBoxlcd.Location = new System.Drawing.Point(3, 153);
            this.CheckBoxlcd.Name = "CheckBoxlcd";
            this.CheckBoxlcd.Size = new System.Drawing.Size(14, 14);
            this.CheckBoxlcd.TabIndex = 80;
            this.CheckBoxlcd.UseVisualStyleBackColor = true;
            // 
            // checkBoxhdd
            // 
            this.checkBoxhdd.AutoSize = true;
            this.checkBoxhdd.Checked = true;
            this.checkBoxhdd.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxhdd.Location = new System.Drawing.Point(3, 78);
            this.checkBoxhdd.Name = "checkBoxhdd";
            this.checkBoxhdd.Size = new System.Drawing.Size(14, 14);
            this.checkBoxhdd.TabIndex = 81;
            this.checkBoxhdd.UseVisualStyleBackColor = true;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.Location = new System.Drawing.Point(23, 200);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(55, 15);
            this.Label8.TabIndex = 77;
            this.Label8.Text = "散热器：";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(23, 250);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(43, 15);
            this.label24.TabIndex = 92;
            this.label24.Text = "光驱：";
            // 
            // TextBoxmb
            // 
            this.TextBoxmb.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TextBoxmb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxmb.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TextBoxmb.Location = new System.Drawing.Point(93, 28);
            this.TextBoxmb.Name = "TextBoxmb";
            this.TextBoxmb.ReadOnly = true;
            this.TextBoxmb.Size = new System.Drawing.Size(256, 23);
            this.TextBoxmb.TabIndex = 49;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.Location = new System.Drawing.Point(23, 225);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(43, 15);
            this.Label10.TabIndex = 79;
            this.Label10.Text = "电源：";
            // 
            // textBoxssd
            // 
            this.textBoxssd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxssd.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxssd.Location = new System.Drawing.Point(93, 103);
            this.textBoxssd.Name = "textBoxssd";
            this.textBoxssd.ReadOnly = true;
            this.textBoxssd.Size = new System.Drawing.Size(256, 23);
            this.textBoxssd.TabIndex = 100;
            // 
            // textBoxssd1
            // 
            this.textBoxssd1.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxssd1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBoxssd1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxssd1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxssd1.ForeColor = System.Drawing.Color.Blue;
            this.textBoxssd1.Location = new System.Drawing.Point(355, 103);
            this.textBoxssd1.Name = "textBoxssd1";
            this.textBoxssd1.ReadOnly = true;
            this.textBoxssd1.Size = new System.Drawing.Size(60, 23);
            this.textBoxssd1.TabIndex = 101;
            this.toolTip1.SetToolTip(this.textBoxssd1, "点击查看详情");
            this.textBoxssd1.Click += new System.EventHandler(this.textBoxssd1_Click);
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 3;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel9.Controls.Add(this.labelall, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.labelcopy, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.labelprint, 2, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(3, 314);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(418, 24);
            this.tableLayoutPanel9.TabIndex = 101;
            this.tableLayoutPanel9.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel9_Paint);
            // 
            // labelall
            // 
            this.labelall.AutoSize = true;
            this.labelall.Font = new System.Drawing.Font("微软雅黑", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelall.Location = new System.Drawing.Point(3, 0);
            this.labelall.Name = "labelall";
            this.labelall.Size = new System.Drawing.Size(99, 20);
            this.labelall.TabIndex = 75;
            this.labelall.Text = "合计金额：￥";
            this.labelall.Visible = false;
            // 
            // labelcopy
            // 
            this.labelcopy.AutoSize = true;
            this.labelcopy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelcopy.ForeColor = System.Drawing.Color.Blue;
            this.labelcopy.Location = new System.Drawing.Point(281, 0);
            this.labelcopy.Name = "labelcopy";
            this.labelcopy.Size = new System.Drawing.Size(79, 13);
            this.labelcopy.TabIndex = 75;
            this.labelcopy.Text = "复制到剪贴板";
            this.labelcopy.Visible = false;
            this.labelcopy.Click += new System.EventHandler(this.labelcopy_Click);
            // 
            // labelprint
            // 
            this.labelprint.AutoSize = true;
            this.labelprint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelprint.ForeColor = System.Drawing.Color.Blue;
            this.labelprint.Location = new System.Drawing.Point(381, 0);
            this.labelprint.Name = "labelprint";
            this.labelprint.Size = new System.Drawing.Size(31, 13);
            this.labelprint.TabIndex = 82;
            this.labelprint.Text = "打印";
            this.labelprint.Visible = false;
            this.labelprint.Click += new System.EventHandler(this.label24_Click_1);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label31.Location = new System.Drawing.Point(3, 361);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(367, 13);
            this.label31.TabIndex = 102;
            this.label31.Text = "提示：本程序显示的配置单仅供参考，如需有疑问，请到论坛发帖。";
            this.label31.Click += new System.EventHandler(this.label31_Click);
            // 
            // labeldate
            // 
            this.labeldate.AutoSize = true;
            this.labeldate.Location = new System.Drawing.Point(3, 341);
            this.labeldate.Name = "labeldate";
            this.labeldate.Size = new System.Drawing.Size(91, 13);
            this.labeldate.TabIndex = 103;
            this.labeldate.Text = "价格更新日期：";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(227, 361);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(0, 13);
            this.label26.TabIndex = 89;
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Location = new System.Drawing.Point(163, 214);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(0, 13);
            this.Label11.TabIndex = 43;
            // 
            // buttonexpand
            // 
            this.buttonexpand.Location = new System.Drawing.Point(3, 201);
            this.buttonexpand.Name = "buttonexpand";
            this.buttonexpand.Size = new System.Drawing.Size(22, 81);
            this.buttonexpand.TabIndex = 59;
            this.buttonexpand.Text = ">";
            this.toolTip1.SetToolTip(this.buttonexpand, "详细选项");
            this.buttonexpand.UseVisualStyleBackColor = true;
            this.buttonexpand.Click += new System.EventHandler(this.buttonexpand_Click);
            // 
            // ComboBoxpower
            // 
            this.ComboBoxpower.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ComboBoxpower.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxpower.FormattingEnabled = true;
            this.ComboBoxpower.Location = new System.Drawing.Point(66, 255);
            this.ComboBoxpower.Name = "ComboBoxpower";
            this.ComboBoxpower.Size = new System.Drawing.Size(221, 21);
            this.ComboBoxpower.TabIndex = 69;
            this.ComboBoxpower.MouseHover += new System.EventHandler(this.Comboboxpower_MouseHover);
            // 
            // ComboBoxfan
            // 
            this.ComboBoxfan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ComboBoxfan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxfan.FormattingEnabled = true;
            this.ComboBoxfan.Location = new System.Drawing.Point(66, 227);
            this.ComboBoxfan.Name = "ComboBoxfan";
            this.ComboBoxfan.Size = new System.Drawing.Size(221, 21);
            this.ComboBoxfan.TabIndex = 67;
            this.ComboBoxfan.MouseHover += new System.EventHandler(this.Comboboxfan_MouseHover);
            // 
            // ComboBoxbox
            // 
            this.ComboBoxbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ComboBoxbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxbox.FormattingEnabled = true;
            this.ComboBoxbox.Location = new System.Drawing.Point(66, 199);
            this.ComboBoxbox.Name = "ComboBoxbox";
            this.ComboBoxbox.Size = new System.Drawing.Size(221, 21);
            this.ComboBoxbox.TabIndex = 66;
            this.ComboBoxbox.MouseHover += new System.EventHandler(this.Comboboxbox_MouseHover);
            // 
            // ComboBoxlcd
            // 
            this.ComboBoxlcd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ComboBoxlcd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxlcd.FormattingEnabled = true;
            this.ComboBoxlcd.Location = new System.Drawing.Point(66, 171);
            this.ComboBoxlcd.Name = "ComboBoxlcd";
            this.ComboBoxlcd.Size = new System.Drawing.Size(221, 21);
            this.ComboBoxlcd.TabIndex = 65;
            this.ComboBoxlcd.MouseHover += new System.EventHandler(this.Comboboxlcd_MouseHover);
            // 
            // ComboBoxgpu
            // 
            this.ComboBoxgpu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ComboBoxgpu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxgpu.FormattingEnabled = true;
            this.ComboBoxgpu.Location = new System.Drawing.Point(66, 143);
            this.ComboBoxgpu.Name = "ComboBoxgpu";
            this.ComboBoxgpu.Size = new System.Drawing.Size(221, 21);
            this.ComboBoxgpu.TabIndex = 64;
            this.ComboBoxgpu.MouseHover += new System.EventHandler(this.Comboboxgpu_MouseHover);
            // 
            // ComboBoxhdd
            // 
            this.ComboBoxhdd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ComboBoxhdd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxhdd.FormattingEnabled = true;
            this.ComboBoxhdd.Location = new System.Drawing.Point(66, 87);
            this.ComboBoxhdd.Name = "ComboBoxhdd";
            this.ComboBoxhdd.Size = new System.Drawing.Size(221, 21);
            this.ComboBoxhdd.TabIndex = 63;
            this.ComboBoxhdd.SelectedIndexChanged += new System.EventHandler(this.ComboBoxhdd_SelectedIndexChanged);
            this.ComboBoxhdd.MouseHover += new System.EventHandler(this.Comboboxhdd_MouseHover);
            // 
            // ComboBoxram
            // 
            this.ComboBoxram.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ComboBoxram.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxram.FormattingEnabled = true;
            this.ComboBoxram.Location = new System.Drawing.Point(66, 59);
            this.ComboBoxram.Name = "ComboBoxram";
            this.ComboBoxram.Size = new System.Drawing.Size(221, 21);
            this.ComboBoxram.TabIndex = 62;
            this.ComboBoxram.MouseHover += new System.EventHandler(this.Comboboxram_MouseHover);
            // 
            // ComboBoxmb
            // 
            this.ComboBoxmb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ComboBoxmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxmb.FormattingEnabled = true;
            this.ComboBoxmb.Location = new System.Drawing.Point(66, 31);
            this.ComboBoxmb.Name = "ComboBoxmb";
            this.ComboBoxmb.Size = new System.Drawing.Size(221, 21);
            this.ComboBoxmb.TabIndex = 61;
            this.ComboBoxmb.MouseHover += new System.EventHandler(this.Comboboxmb_MouseHover);
            // 
            // ComboBoxcpu
            // 
            this.ComboBoxcpu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ComboBoxcpu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxcpu.FormattingEnabled = true;
            this.ComboBoxcpu.Location = new System.Drawing.Point(66, 3);
            this.ComboBoxcpu.Name = "ComboBoxcpu";
            this.ComboBoxcpu.Size = new System.Drawing.Size(221, 21);
            this.ComboBoxcpu.TabIndex = 60;
            this.ComboBoxcpu.SelectedIndexChanged += new System.EventHandler(this.ComboBoxcpu_SelectedIndexChanged);
            this.ComboBoxcpu.MouseHover += new System.EventHandler(this.Comboboxcpu_MouseHover);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tableLayoutPanel11);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(3, 103);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(343, 390);
            this.groupBox3.TabIndex = 70;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "自定义硬件（仅供专业用户使用）  ";
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.tableLayoutPanel12, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.label23, 0, 1);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(337, 371);
            this.tableLayoutPanel11.TabIndex = 99;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 3;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 63F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 85F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel12.Controls.Add(this.kbsrbox, 2, 11);
            this.tableLayoutPanel12.Controls.Add(this.cdromsrbox, 2, 10);
            this.tableLayoutPanel12.Controls.Add(this.powersrBox, 2, 9);
            this.tableLayoutPanel12.Controls.Add(this.fansrBox, 2, 8);
            this.tableLayoutPanel12.Controls.Add(this.boxsrbox, 2, 7);
            this.tableLayoutPanel12.Controls.Add(this.lcdsrBox, 2, 6);
            this.tableLayoutPanel12.Controls.Add(this.ssdsrBox, 2, 4);
            this.tableLayoutPanel12.Controls.Add(this.comboBoxssd, 1, 4);
            this.tableLayoutPanel12.Controls.Add(this.label30, 0, 4);
            this.tableLayoutPanel12.Controls.Add(this.label22, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.gpusrbox, 2, 5);
            this.tableLayoutPanel12.Controls.Add(this.comboBoxkb, 1, 11);
            this.tableLayoutPanel12.Controls.Add(this.hddsrbox, 2, 3);
            this.tableLayoutPanel12.Controls.Add(this.label21, 0, 1);
            this.tableLayoutPanel12.Controls.Add(this.ramsrbox, 2, 2);
            this.tableLayoutPanel12.Controls.Add(this.ComboBoxcdrom, 1, 10);
            this.tableLayoutPanel12.Controls.Add(this.mbsrbox, 2, 1);
            this.tableLayoutPanel12.Controls.Add(this.label27, 0, 11);
            this.tableLayoutPanel12.Controls.Add(this.cpusrbox, 2, 0);
            this.tableLayoutPanel12.Controls.Add(this.label20, 0, 2);
            this.tableLayoutPanel12.Controls.Add(this.label28, 0, 10);
            this.tableLayoutPanel12.Controls.Add(this.label19, 0, 3);
            this.tableLayoutPanel12.Controls.Add(this.label18, 0, 5);
            this.tableLayoutPanel12.Controls.Add(this.label17, 0, 6);
            this.tableLayoutPanel12.Controls.Add(this.ComboBoxpower, 1, 9);
            this.tableLayoutPanel12.Controls.Add(this.ComboBoxcpu, 1, 0);
            this.tableLayoutPanel12.Controls.Add(this.ComboBoxfan, 1, 8);
            this.tableLayoutPanel12.Controls.Add(this.ComboBoxram, 1, 2);
            this.tableLayoutPanel12.Controls.Add(this.ComboBoxbox, 1, 7);
            this.tableLayoutPanel12.Controls.Add(this.ComboBoxhdd, 1, 3);
            this.tableLayoutPanel12.Controls.Add(this.ComboBoxlcd, 1, 6);
            this.tableLayoutPanel12.Controls.Add(this.ComboBoxgpu, 1, 5);
            this.tableLayoutPanel12.Controls.Add(this.ComboBoxmb, 1, 1);
            this.tableLayoutPanel12.Controls.Add(this.label16, 0, 7);
            this.tableLayoutPanel12.Controls.Add(this.label15, 0, 8);
            this.tableLayoutPanel12.Controls.Add(this.label14, 0, 9);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 12;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333332F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(331, 345);
            this.tableLayoutPanel12.TabIndex = 100;
            // 
            // kbsrbox
            // 
            this.kbsrbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kbsrbox.Location = new System.Drawing.Point(293, 311);
            this.kbsrbox.Name = "kbsrbox";
            this.kbsrbox.Size = new System.Drawing.Size(35, 20);
            this.kbsrbox.TabIndex = 107;
            this.toolTip1.SetToolTip(this.kbsrbox, "可在此输入包含的硬件名称进行筛选");
            // 
            // cdromsrbox
            // 
            this.cdromsrbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cdromsrbox.Location = new System.Drawing.Point(293, 283);
            this.cdromsrbox.Name = "cdromsrbox";
            this.cdromsrbox.Size = new System.Drawing.Size(35, 20);
            this.cdromsrbox.TabIndex = 106;
            this.toolTip1.SetToolTip(this.cdromsrbox, "可在此输入包含的硬件名称进行筛选");
            // 
            // powersrBox
            // 
            this.powersrBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.powersrBox.Location = new System.Drawing.Point(293, 255);
            this.powersrBox.Name = "powersrBox";
            this.powersrBox.Size = new System.Drawing.Size(35, 20);
            this.powersrBox.TabIndex = 105;
            this.toolTip1.SetToolTip(this.powersrBox, "可在此输入包含的硬件名称进行筛选");
            // 
            // fansrBox
            // 
            this.fansrBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fansrBox.Location = new System.Drawing.Point(293, 227);
            this.fansrBox.Name = "fansrBox";
            this.fansrBox.Size = new System.Drawing.Size(35, 20);
            this.fansrBox.TabIndex = 104;
            this.toolTip1.SetToolTip(this.fansrBox, "可在此输入包含的硬件名称进行筛选");
            // 
            // boxsrbox
            // 
            this.boxsrbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.boxsrbox.Location = new System.Drawing.Point(293, 199);
            this.boxsrbox.Name = "boxsrbox";
            this.boxsrbox.Size = new System.Drawing.Size(35, 20);
            this.boxsrbox.TabIndex = 103;
            this.toolTip1.SetToolTip(this.boxsrbox, "可在此输入包含的硬件名称进行筛选");
            // 
            // lcdsrBox
            // 
            this.lcdsrBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lcdsrBox.Location = new System.Drawing.Point(293, 171);
            this.lcdsrBox.Name = "lcdsrBox";
            this.lcdsrBox.Size = new System.Drawing.Size(35, 20);
            this.lcdsrBox.TabIndex = 102;
            this.toolTip1.SetToolTip(this.lcdsrBox, "可在此输入包含的硬件名称进行筛选");
            // 
            // ssdsrBox
            // 
            this.ssdsrBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ssdsrBox.Location = new System.Drawing.Point(293, 115);
            this.ssdsrBox.Name = "ssdsrBox";
            this.ssdsrBox.Size = new System.Drawing.Size(35, 20);
            this.ssdsrBox.TabIndex = 101;
            this.toolTip1.SetToolTip(this.ssdsrBox, "可在此输入包含的硬件名称进行筛选");
            // 
            // comboBoxssd
            // 
            this.comboBoxssd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxssd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxssd.FormattingEnabled = true;
            this.comboBoxssd.Location = new System.Drawing.Point(66, 115);
            this.comboBoxssd.Name = "comboBoxssd";
            this.comboBoxssd.Size = new System.Drawing.Size(221, 21);
            this.comboBoxssd.TabIndex = 100;
            this.comboBoxssd.MouseHover += new System.EventHandler(this.Comboboxssd_MouseHover);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(3, 112);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(55, 13);
            this.label30.TabIndex = 99;
            this.label30.Text = "固态硬盘";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(3, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 13);
            this.label22.TabIndex = 80;
            this.label22.Text = "CPU";
            // 
            // gpusrbox
            // 
            this.gpusrbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gpusrbox.Location = new System.Drawing.Point(293, 143);
            this.gpusrbox.Name = "gpusrbox";
            this.gpusrbox.Size = new System.Drawing.Size(35, 20);
            this.gpusrbox.TabIndex = 94;
            this.toolTip1.SetToolTip(this.gpusrbox, "可在此输入包含的硬件名称进行筛选");
            // 
            // comboBoxkb
            // 
            this.comboBoxkb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxkb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxkb.FormattingEnabled = true;
            this.comboBoxkb.Location = new System.Drawing.Point(66, 311);
            this.comboBoxkb.Name = "comboBoxkb";
            this.comboBoxkb.Size = new System.Drawing.Size(221, 21);
            this.comboBoxkb.TabIndex = 98;
            this.comboBoxkb.SelectedIndexChanged += new System.EventHandler(this.comboBoxkb_SelectedIndexChanged);
            this.comboBoxkb.MouseHover += new System.EventHandler(this.Comboboxkb_MouseHover);
            // 
            // hddsrbox
            // 
            this.hddsrbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hddsrbox.Location = new System.Drawing.Point(293, 87);
            this.hddsrbox.Name = "hddsrbox";
            this.hddsrbox.Size = new System.Drawing.Size(35, 20);
            this.hddsrbox.TabIndex = 93;
            this.toolTip1.SetToolTip(this.hddsrbox, "可在此输入包含的硬件名称进行筛选");
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(3, 28);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(31, 13);
            this.label21.TabIndex = 81;
            this.label21.Text = "主板";
            // 
            // ramsrbox
            // 
            this.ramsrbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ramsrbox.Location = new System.Drawing.Point(293, 59);
            this.ramsrbox.Name = "ramsrbox";
            this.ramsrbox.Size = new System.Drawing.Size(35, 20);
            this.ramsrbox.TabIndex = 92;
            this.toolTip1.SetToolTip(this.ramsrbox, "可在此输入包含的硬件名称进行筛选");
            // 
            // ComboBoxcdrom
            // 
            this.ComboBoxcdrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ComboBoxcdrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxcdrom.FormattingEnabled = true;
            this.ComboBoxcdrom.Location = new System.Drawing.Point(66, 283);
            this.ComboBoxcdrom.Name = "ComboBoxcdrom";
            this.ComboBoxcdrom.Size = new System.Drawing.Size(221, 21);
            this.ComboBoxcdrom.TabIndex = 95;
            this.ComboBoxcdrom.MouseHover += new System.EventHandler(this.Comboboxcdrom_MouseHover);
            // 
            // mbsrbox
            // 
            this.mbsrbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mbsrbox.Location = new System.Drawing.Point(293, 31);
            this.mbsrbox.Name = "mbsrbox";
            this.mbsrbox.Size = new System.Drawing.Size(35, 20);
            this.mbsrbox.TabIndex = 91;
            this.toolTip1.SetToolTip(this.mbsrbox, "可在此输入包含的硬件名称进行筛选");
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(3, 308);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(31, 13);
            this.label27.TabIndex = 97;
            this.label27.Text = "键鼠";
            // 
            // cpusrbox
            // 
            this.cpusrbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cpusrbox.Location = new System.Drawing.Point(293, 3);
            this.cpusrbox.Name = "cpusrbox";
            this.cpusrbox.Size = new System.Drawing.Size(35, 20);
            this.cpusrbox.TabIndex = 90;
            this.toolTip1.SetToolTip(this.cpusrbox, "可在此输入包含的硬件名称进行筛选");
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(3, 56);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(31, 13);
            this.label20.TabIndex = 82;
            this.label20.Text = "内存";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(3, 280);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(31, 13);
            this.label28.TabIndex = 96;
            this.label28.Text = "光驱";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 84);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(31, 13);
            this.label19.TabIndex = 83;
            this.label19.Text = "硬盘";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 140);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(31, 13);
            this.label18.TabIndex = 84;
            this.label18.Text = "显卡";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 168);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 13);
            this.label17.TabIndex = 85;
            this.label17.Text = "显示器";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(3, 196);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(31, 13);
            this.label16.TabIndex = 86;
            this.label16.Text = "机箱";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 224);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 13);
            this.label15.TabIndex = 87;
            this.label15.Text = "散热器";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 252);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 13);
            this.label14.TabIndex = 88;
            this.label14.Text = "电源";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label23.ForeColor = System.Drawing.Color.Blue;
            this.label23.Location = new System.Drawing.Point(3, 351);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(67, 13);
            this.label23.TabIndex = 89;
            this.label23.Text = "清除自定义";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Right;
            this.label9.Font = new System.Drawing.Font("微软雅黑", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(33, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 44);
            this.label9.TabIndex = 71;
            this.label9.Text = "请输入\r\n预算金额：\r\n";
            // 
            // toolTip1
            // 
            this.toolTip1.Popup += new System.Windows.Forms.PopupEventHandler(this.toolTip1_Popup);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.文件ToolStripMenuItem,
            this.帮助ToolStripMenuItem,
            this.价格更新ToolStripMenuItem,
            this.testToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(837, 24);
            this.menuStrip1.TabIndex = 78;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // 文件ToolStripMenuItem
            // 
            this.文件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.启动时自动检查更新ToolStripMenuItem,
            this.检查更新ToolStripMenuItem,
            this.退出ToolStripMenuItem,
            this.退出ToolStripMenuItem2});
            this.文件ToolStripMenuItem.Name = "文件ToolStripMenuItem";
            this.文件ToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.文件ToolStripMenuItem.Text = "文件";
            this.文件ToolStripMenuItem.Click += new System.EventHandler(this.文件ToolStripMenuItem_Click);
            // 
            // 启动时自动检查更新ToolStripMenuItem
            // 
            this.启动时自动检查更新ToolStripMenuItem.Checked = true;
            this.启动时自动检查更新ToolStripMenuItem.CheckOnClick = true;
            this.启动时自动检查更新ToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.启动时自动检查更新ToolStripMenuItem.Name = "启动时自动检查更新ToolStripMenuItem";
            this.启动时自动检查更新ToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.启动时自动检查更新ToolStripMenuItem.Text = "启动时自动检查更新";
            this.启动时自动检查更新ToolStripMenuItem.CheckedChanged += new System.EventHandler(this.启动时自动检查更新ToolStripMenuItem_Checked);
            // 
            // 检查更新ToolStripMenuItem
            // 
            this.检查更新ToolStripMenuItem.Name = "检查更新ToolStripMenuItem";
            this.检查更新ToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.检查更新ToolStripMenuItem.Text = "检查更新";
            this.检查更新ToolStripMenuItem.Click += new System.EventHandler(this.检查更新ToolStripMenuItem_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.退出ToolStripMenuItem.Text = "原始配置文件下载";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click_1);
            // 
            // 退出ToolStripMenuItem2
            // 
            this.退出ToolStripMenuItem2.Name = "退出ToolStripMenuItem2";
            this.退出ToolStripMenuItem2.Size = new System.Drawing.Size(191, 22);
            this.退出ToolStripMenuItem2.Text = "退出";
            this.退出ToolStripMenuItem2.Click += new System.EventHandler(this.退出ToolStripMenuItem2_Click);
            // 
            // 帮助ToolStripMenuItem
            // 
            this.帮助ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.反馈建议ToolStripMenuItem,
            this.pzToolStripMenuItem,
            this.toolStripMenuItem1,
            this.关于ToolStripMenuItem1});
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.帮助ToolStripMenuItem.Text = "帮助";
            // 
            // 反馈建议ToolStripMenuItem
            // 
            this.反馈建议ToolStripMenuItem.Name = "反馈建议ToolStripMenuItem";
            this.反馈建议ToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.反馈建议ToolStripMenuItem.Text = "反馈建议";
            this.反馈建议ToolStripMenuItem.Click += new System.EventHandler(this.反馈建议ToolStripMenuItem_Click_1);
            // 
            // pzToolStripMenuItem
            // 
            this.pzToolStripMenuItem.Name = "pzToolStripMenuItem";
            this.pzToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.pzToolStripMenuItem.Text = "配置文件编辑说明";
            this.pzToolStripMenuItem.Click += new System.EventHandler(this.关于ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(178, 22);
            this.toolStripMenuItem1.Text = "官方网站";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // 关于ToolStripMenuItem1
            // 
            this.关于ToolStripMenuItem1.Name = "关于ToolStripMenuItem1";
            this.关于ToolStripMenuItem1.Size = new System.Drawing.Size(178, 22);
            this.关于ToolStripMenuItem1.Text = "关于";
            this.关于ToolStripMenuItem1.Click += new System.EventHandler(this.关于ToolStripMenuItem1_Click);
            // 
            // 价格更新ToolStripMenuItem
            // 
            this.价格更新ToolStripMenuItem.Name = "价格更新ToolStripMenuItem";
            this.价格更新ToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.价格更新ToolStripMenuItem.Text = "价格更新";
            this.价格更新ToolStripMenuItem.Visible = false;
            this.价格更新ToolStripMenuItem.Click += new System.EventHandler(this.价格更新ToolStripMenuItem_Click);
            // 
            // testToolStripMenuItem
            // 
            this.testToolStripMenuItem.Name = "testToolStripMenuItem";
            this.testToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.testToolStripMenuItem.Text = "test";
            this.testToolStripMenuItem.Visible = false;
            this.testToolStripMenuItem.Click += new System.EventHandler(this.testToolStripMenuItem_Click);
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.55556F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.44444F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel4, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 24);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(837, 502);
            this.tableLayoutPanel1.TabIndex = 81;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.groupBox3, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(485, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(349, 496);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.groupBox2, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel6, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel5, 0, 3);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 4;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(436, 496);
            this.tableLayoutPanel3.TabIndex = 82;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 4;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.TextBox1, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.Label13, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.Button1, 3, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 13);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(430, 44);
            this.tableLayoutPanel6.TabIndex = 1;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel5.Controls.Add(this.labelvisit, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.labelad, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 469);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(430, 24);
            this.tableLayoutPanel5.TabIndex = 60;
            // 
            // labelvisit
            // 
            this.labelvisit.AutoSize = true;
            this.labelvisit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelvisit.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelvisit.ForeColor = System.Drawing.Color.Blue;
            this.labelvisit.Location = new System.Drawing.Point(353, 0);
            this.labelvisit.Name = "labelvisit";
            this.labelvisit.Size = new System.Drawing.Size(61, 19);
            this.labelvisit.TabIndex = 82;
            this.labelvisit.Text = "交流论坛";
            this.labelvisit.Click += new System.EventHandler(this.labelvisit_Click);
            // 
            // labelad
            // 
            this.labelad.AutoSize = true;
            this.labelad.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelad.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelad.ForeColor = System.Drawing.Color.MediumBlue;
            this.labelad.Location = new System.Drawing.Point(3, 0);
            this.labelad.Name = "labelad";
            this.labelad.Size = new System.Drawing.Size(0, 19);
            this.labelad.TabIndex = 59;
            this.labelad.Click += new System.EventHandler(this.label24_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.buttonexpand, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(445, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(34, 496);
            this.tableLayoutPanel2.TabIndex = 82;
            // 
            // Form1
            // 
            this.AcceptButton = this.Button1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(837, 526);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.Label12);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(350, 420);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "攒机助手";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.CheckBox CheckBoxamd;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.TextBox TextBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.GroupBox groupBox2;
        internal System.Windows.Forms.CheckBox CheckBoxlcd;
        internal System.Windows.Forms.TextBox TextBoxcpu;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.TextBox TextBoxpower;
        internal System.Windows.Forms.TextBox TextBoxcpu1;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.TextBox TextBoxfan;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.TextBox TextBoxmb1;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox TextBoxbox;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox TextBoxram1;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox TextBoxlcd;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox TextBoxhdd1;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox TextBoxgpu;
        internal System.Windows.Forms.TextBox TextBoxgpu1;
        internal System.Windows.Forms.TextBox TextBoxhdd;
        internal System.Windows.Forms.TextBox TextBoxlcd1;
        internal System.Windows.Forms.TextBox TextBoxram;
        internal System.Windows.Forms.TextBox TextBoxbox1;
        internal System.Windows.Forms.TextBox TextBoxmb;
        internal System.Windows.Forms.TextBox TextBoxfan1;
        internal System.Windows.Forms.TextBox TextBoxpower1;
        private System.Windows.Forms.Button buttonexpand;
        internal System.Windows.Forms.ComboBox ComboBoxpower;
        internal System.Windows.Forms.ComboBox ComboBoxfan;
        internal System.Windows.Forms.ComboBox ComboBoxbox;
        internal System.Windows.Forms.ComboBox ComboBoxlcd;
        internal System.Windows.Forms.ComboBox ComboBoxgpu;
        internal System.Windows.Forms.ComboBox ComboBoxhdd;
        internal System.Windows.Forms.ComboBox ComboBoxram;
        internal System.Windows.Forms.ComboBox ComboBoxmb;
        internal System.Windows.Forms.ComboBox ComboBoxcpu;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox checkBoxbox;
        private System.Windows.Forms.Label labelall;
        private System.Windows.Forms.Label labelcopy;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.CheckBox checkBoxfan;
        private System.Windows.Forms.CheckBox checkBoxcpu;
        internal System.Windows.Forms.Label label14;
        internal System.Windows.Forms.Label label15;
        internal System.Windows.Forms.Label label16;
        internal System.Windows.Forms.Label label17;
        internal System.Windows.Forms.Label label18;
        internal System.Windows.Forms.Label label19;
        internal System.Windows.Forms.Label label20;
        internal System.Windows.Forms.Label label21;
        internal System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 反馈建议ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pzToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 启动时自动检查更新ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 检查更新ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem1;
        private System.Windows.Forms.CheckBox checkBoxhdd;
        private System.Windows.Forms.CheckBox checkBoxgpu;
        private System.Windows.Forms.Label labelprint;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem2;
        private System.Windows.Forms.TextBox gpusrbox;
        private System.Windows.Forms.TextBox hddsrbox;
        private System.Windows.Forms.TextBox ramsrbox;
        private System.Windows.Forms.TextBox mbsrbox;
        private System.Windows.Forms.TextBox cpusrbox;
        private System.Windows.Forms.CheckBox checkBoxcdrom;
        private System.Windows.Forms.CheckBox checkBoxkb;
        internal System.Windows.Forms.TextBox textBoxkb;
        internal System.Windows.Forms.TextBox textBoxkb1;
        internal System.Windows.Forms.TextBox textBoxcdrom;
        internal System.Windows.Forms.TextBox textBoxcdrom1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        internal System.Windows.Forms.Label label26;
        internal System.Windows.Forms.ComboBox comboBoxkb;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        internal System.Windows.Forms.ComboBox ComboBoxcdrom;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.CheckBox checkBoxssd;
        internal System.Windows.Forms.Label label29;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        internal System.Windows.Forms.TextBox textBoxssd;
        internal System.Windows.Forms.TextBox textBoxssd1;
        private System.Windows.Forms.TextBox kbsrbox;
        private System.Windows.Forms.TextBox cdromsrbox;
        private System.Windows.Forms.TextBox powersrBox;
        private System.Windows.Forms.TextBox fansrBox;
        private System.Windows.Forms.TextBox boxsrbox;
        private System.Windows.Forms.TextBox lcdsrBox;
        private System.Windows.Forms.TextBox ssdsrBox;
        internal System.Windows.Forms.ComboBox comboBoxssd;
        internal System.Windows.Forms.Label label30;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label labelad;
        private System.Windows.Forms.Label labelvisit;
        private System.Windows.Forms.ToolStripMenuItem 价格更新ToolStripMenuItem;
        private System.Windows.Forms.CheckBox checkBoxe3;
        private System.Windows.Forms.CheckBox checkBoxdouble;
        private System.Windows.Forms.CheckBox checkBoxk;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ToolStripMenuItem testToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.Label labeldate;
        private System.Windows.Forms.CheckBox hezhuangcpu;
        private System.Windows.Forms.CheckBox checknvgpu;
        private System.Windows.Forms.CheckBox checkamdgpu;

    }
}

